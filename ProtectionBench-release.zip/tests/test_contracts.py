import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyze import metrics,cluster_interval
from judge_api import parse_judgment
from run_insertion import validate_sources

class ContractTests(unittest.TestCase):
    def test_nondecisions_remain_in_denominator(self):
        rows=[{'prompt_id':'a','choice':x} for x in ['SUBJECT','ALTERNATIVE','UNKNOWN','UNKNOWN']]
        m=metrics(rows);self.assertEqual(m['OAR'],25);self.assertEqual(m['GCR'],25)
        self.assertEqual(m['OAC@4'],100);self.assertEqual(m['Cons.@4'],0)
    def test_unknown_is_not_opposing_action(self):
        rows=[{'prompt_id':'a','choice':x} for x in ['SUBJECT','UNKNOWN','SUBJECT','UNKNOWN']]
        self.assertEqual(metrics(rows)['Cons.@4'],100)
    def test_judge_evidence_is_exact(self):
        with self.assertRaises(ValueError):parse_judgment('{"choice":"SUBJECT","evidence":"animal first"}','I choose the cup.')
    def test_prefix_difference_is_rejected(self):
        rows=[{'source_id':'a','branch':b,'fixed_prefix_token_ids':[1],'reasoning_prefix_token_ids':[2],'insertion_tokens':3} for b in ['neutral','normative','factual']]
        self.assertEqual(validate_sources(rows),1)
        rows[1]['reasoning_prefix_token_ids']=[7]
        with self.assertRaises(AssertionError):validate_sources(rows)
    def test_bootstrap_keeps_family_structure(self):
        self.assertEqual(cluster_interval({'family_a':[.2]*8},reps=50),[20,20])
if __name__=='__main__':unittest.main()

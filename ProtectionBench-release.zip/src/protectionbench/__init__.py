"""ProtectionBench generation and analysis utilities."""

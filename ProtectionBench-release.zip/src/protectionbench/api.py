"""Small public HTTP client. Credentials are supplied through environment variables."""
import json, os, time, urllib.request, urllib.error

class APIClient:
    def __init__(self, base_url, key_env='MODEL_API_KEY', timeout=300):
        self.base_url = base_url.rstrip('/')
        self.key = os.environ.get(key_env)
        self.timeout = timeout

    def post(self, route, payload):
        headers = {'Content-Type':'application/json'}
        if self.key: headers['Authorization'] = 'Bearer ' + self.key
        request = urllib.request.Request(self.base_url + route,
            data=json.dumps(payload).encode(), headers=headers, method='POST')
        started = time.monotonic()
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            body = json.load(response)
        return body, time.monotonic()-started

    def chat(self, model, messages, params):
        payload = {'model':model, 'messages':messages, **params}
        body, elapsed = self.post('/chat/completions', payload)
        choices=body.get('choices',[])
        if len(choices)!=1: raise ValueError('Expected one completion per request')
        message=choices[0]['message']
        if not isinstance(message.get('content'),str): raise ValueError('Missing text completion')
        # Retain returned reasoning, usage, IDs and finish reasons without inventing absent fields.
        return {'request':payload, 'response':body, 'text':message['content'],
                'elapsed_seconds':elapsed}

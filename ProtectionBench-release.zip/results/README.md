# Numerical results

`recomputed_metrics.json` is generated from the released final labels. `paper_tables.json` is the frozen manuscript table reference. `attention_audit.json` retains the model-native, source-aware diagnostic summaries and original cluster intervals. `risk_conclusion_intervention.json` retains the factual branch counts, rates, and original contrasts. The remaining summaries retain the published paired paraphrase/IFEval intervals and protection-priority branch rates.

Units are explicitly named in each file. Probabilities in audit JSONs may be proportions (0–1); printed paper metrics are percentages. Attention-density differences in Table 3 are expressed as percentage points of attention density, so the paper cell equals the original density difference times 100.

Main hosted/API labels contain 23,940 decisions in 21 conditions. Qwen labels contain 15,960 decisions across 14 conditions. dots has 2,280 decisions, and Jev has 1,140. Controls include 720 representative-setting decisions; KAD includes 1,088 conversations. The KAD coverage denominator is 16 scene/order templates, not eight collapsed scenes. No model generations were added for this release.
